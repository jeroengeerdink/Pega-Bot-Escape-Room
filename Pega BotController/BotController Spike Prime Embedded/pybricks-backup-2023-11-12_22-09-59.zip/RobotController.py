from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch
from usys import stdin, stdout


STEP_UNIT = 100
SPEED = 200

hub = PrimeHub()

left_motor=Motor(Port.C,Direction.COUNTERCLOCKWISE) 
right_motor=Motor(Port.D)
sensor = ColorSensor(Port.B)

drive_base=DriveBase(left_motor,right_motor,wheel_diameter=56,axle_track=112)

def cb_onBlackLineDetected(event):
    pass

# commands follow the following structure
#
# [action] > [param] | [param]
# e.g. drive>50

def handleCommand(cmd):
    cmdParts = cmd.split(">")
    action = cmdParts[0]
    params = cmdParts[1].split("|")

    if action == "drive":
        drive(int(params[0]))
    elif action == "turn":
        turn(int(params[0]))
    elif action == "display":
        hub.display.text(params[0])
    else:
        pass
        #motor.stop()

def checkSensors():
    if sensor.reflection() <= 40:
        stdout.write("linedetected")
        stdout.flush()
        return True
    return False


def drive(steps):
    drive_base.straight(steps * STEP_UNIT, wait=False)
    while not drive_base.done():
        wait(10)
        if checkSensors():
            drive_base.stop()
            break

def turn(degrees):
    drive_base.turn(degrees)

if __name__ == '__main__':
    handleCommand("drive>5")
    handleCommand("display>Hello")
    handleCommand("drive>-5")
    handleCommand("turn>90")
    handleCommand("turn>-180")