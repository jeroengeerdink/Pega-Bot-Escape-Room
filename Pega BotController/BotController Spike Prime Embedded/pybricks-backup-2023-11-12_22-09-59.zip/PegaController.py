# NOTE: Run this program with the latest
# firmware provided via https://beta.pybricks.com/

from pybricks.pupdevices import Motor
from pybricks.hubs import PrimeHub
from pybricks.parameters import Port
from pybricks.tools import wait
from pybricks.parameters import Color
from pybricks import version


# Standard MicroPython modules
from usys import stdin, stdout
from uselect import poll

import RobotController

#motor = Motor(Port.A)
hub = PrimeHub()

# Optional: Register stdin for polling. This allows
# you to wait for incoming data without blocking.
keyboard = poll()
keyboard.register(stdin)

def main():
    keyboard = poll()
    keyboard.register(stdin)

    #stdout.buffer.write(b"rdy")
    hub.light.on(Color.RED)
    hub.display.text("k")

    cmd = b""

    #def handleEvent(event):
    #    print
    #    stdout.write(event)
    #RobotController.onBlackLineDetected(handleEvent)

    while True:
        #stdout.buffer.write(b"start loop")
        # Optional: Check available input.
        while not keyboard.poll(0):
            wait(10)
        char = b""
        # Read three bytes.
        try:
            char = stdin.buffer.read(1)
            #stdout.buffer.write(char)
            if char == b"\r":
                param = str(cmd, "utf-8")
                RobotController.handleCommand(param)
                #stdout.buffer.write(bytearray("OK"))
                stdout.write("OK")
                stdout.flush()
                cmd = b""
            elif char != b"":
                cmd = cmd + char
        except Exception as e:
            stdout.buffer.write(bytearray(str(e)))
            cmd = b""
            hub.display.text("Error")


if __name__ == '__main__':
    main()